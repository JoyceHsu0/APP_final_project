<?php
header('Content-Type: application/json; charset=UTF-8'); //設定資料類型為 json，編碼 utf-8

	//--------帳號----------//
	if(@$_POST["p_id"] != "")
	{
		$p_id=$_POST["p_id"];	
      	//echo $p_id;
      	
	}	
	else
	{
		$p_id="";
	}

	if(@$_POST["p_num"] != "")
	{
		$p_num=$_POST["p_num"];	
		//echo $p_num;
	}
	else
	{
		$p_num="";
	}
   if(@$_POST["p_img"] != "")
    {
      $p_img=$_POST["p_img"];	
      //echo $p_img;
    }
    else
    {
      $p_img="";
    }

//------------讀取資料庫--------------//	

	$servername = "192.168.2.200";
	$username = "slionf26_app_2023";
	$password = "root123456";
	$dbname = "slionf26_app_2023";
	$conn = new mysqli($servername, $username, $password, $dbname);

	//------------------------------------//
	// 建立資料庫連線
	$conn = new mysqli($servername, $username, $password, $dbname);
	// 確認資料是否正常連線
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	
	if($p_id !="")
	{ 
      $sql = "INSERT INTO `cart`(`p_id`, `p_num`, `p_name`, `p_price`, `p_img`) 
      VALUES ('".@$p_id."', '".@$p_num."', 
      (SELECT p_name FROM product WHERE ID = ".@$p_id."), 
      (SELECT price FROM product WHERE ID = ".@$p_id."), 
      '".@$p_img."'
      ) 
      ON DUPLICATE KEY UPDATE `p_num` = '".@$p_num."';";
      $result = $conn->query($sql);
	}
$conn->close();
	//------------------------------------------------
	//輸出結果JSON格式		
	$dataarray= array(
	 "p_id" => @$p_id,//
	 "p_num" => @$p_num,//	
     "p_name" => @$p_name,
     "p_price" => @$p_price,
     "p_img" => @$p_img
      
	);	
	$messageArr["data"] = $dataarray;
	//------------------------------------------------------
	


if(!empty($_POST['p_id']))
{
	http_response_code(200);
    echo json_encode($messageArr);	
}
else
{		
	http_response_code(404);	
	$messageArr["data"] =[];//因為沒有帳號，我們就預設讓它為空陣列
	echo json_encode($messageArr);	
}




?>

