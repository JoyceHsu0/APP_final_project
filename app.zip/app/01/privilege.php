<?php 
$priv = 3;
?>