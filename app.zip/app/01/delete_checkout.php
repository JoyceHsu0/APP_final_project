<?php include("connection.php"); ?>
<?php 
include("session.php");
include("connection.php");
include("privilege.php");

// 送出編碼的MySQL指令
mysqli_query($link, 'SET CHARACTER SET utf8');
mysqli_query($link, "SET collation_connection = 'utf8_unicode_ci'");

$id = $_GET['id'];

if ($result = mysqli_query($link, "DELETE FROM checkout where checkout_id ='$id'")){
    if($priv == 2)
        $url = "checkout.php";
    else
        $url = "checkout_admin.php";
    header("Location:$url");
}
else{
    echo $product;
}
?>