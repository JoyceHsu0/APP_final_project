<?php
header('Content-Type: application/json; charset=UTF-8'); //設定資料類型為 json，編碼 utf-8

//------------讀取資料庫--------------//	

	$servername = "192.168.2.200";
	$username = "slionf26_app_2023";
	$password = "root123456";
	$dbname = "slionf26_app_2023";
	$conn = new mysqli($servername, $username, $password, $dbname);

	//------------------------------------//
	// 建立資料庫連線
	$conn = new mysqli($servername, $username, $password, $dbname);
	// 確認資料是否正常連線
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$conn->query("SET NAMES utf8"); //very importent!

	$sql = "SELECT * FROM `cart` ";
	$result = $conn->query($sql);
 	
	$messageArr = array();
	$dataarray= array();

	$IDarray = array();
	$namearray=array();
	$amountarray = array();
	$pricearray = array();


	//data
	date_default_timezone_set('Asia/Taipei');
    $year = date('Y');
    $month = date('m');
    $day = date('d');
    $date = $year . "-" . $month . "-" . $day;
	$a=rand(0,2147483647);
	
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
          $IDarray[] = $row["p_id"];
          $namearray[] = $row["p_name"];
          $amountarray[] = $row["p_num"];
          $pricearray[] = $row["p_price"];
               
		 $dataarray[] = $row;//將資料一筆一筆丟進dataarray
			
		}
	} 

    $amount = "";
    $product = "";

	$cnt = count($IDarray);
	$total = 0;
	for ($j = 0; $j < $cnt; $j++) {
      $total += $amountarray[$j] * $pricearray[$j];
      if ($product == "") {
            $product .= $namearray[$j];
            $amount .= $amountarray[$j];
        } else {
            $product .= "," . $namearray[$j];
            $amount .= "," . $amountarray[$j];
        }
    }

    if($product != ""){
      $sql = "INSERT INTO `checkout`(`checkout_id`, `account`, `product_name`, `product_amount`, `total`, `date`) 
      VALUES ('$a','appuser','$product','$amount','$total','$date');";
      $result = $conn->query($sql);
    }

	

$conn->close();
	//------------------------------------------------

echo json_encode($IDarray, JSON_UNESCAPED_UNICODE);
echo $product;
echo $amount;
echo json_encode($pricearray, JSON_UNESCAPED_UNICODE);
echo $date;
echo $total;

?>