<?php include("connection.php"); ?>
<?php include("privilege.php"); ?>
<?php
header('Content-Type: application/json; charset=UTF-8');
// // 資料庫查詢(送出查詢的SQL指令)
$sql = "SELECT * FROM product";
$messageArr = array();
$pict_bot = "";
$pict_top = "";
$data = "";
$cart = "";
$add_cart = "";
$name = "";
$content = "";
$price = "";
$id = (isset($_GET['id'])) ? $_GET['id'] : 1;
if ($result = mysqli_query($link, $sql)) {
    mysqli_data_seek($result, ($_GET['id']) - 1);

    $row = mysqli_fetch_assoc($result);
    /*$name = $row["p_name"];
    $content = $row["content"];
    $price = $row["price"];*/
    $messageArr["p_name"]= $row["p_name"];
    $messageArr["content"]= $row["content"];
    $messageArr["price"]= $row["price"];
    $messageArr["image"] = "https://s0854006.lionfree.net/app/img/{$row["picture"]}";

    foreach($messageArr as $key => $value){
        $new_messageArr[urlencode($key)] = urlencode($value);
    }
    $messageArr_url = json_encode($new_messageArr);
    $messageArr = urldecode($messageArr_url);

}

mysqli_free_result($result); // 釋放佔用的記憶體
mysqli_close($link); // 關閉資料庫連結

if(!empty($_GET['id']))
{
	http_response_code(200);
    echo $messageArr;	
}
else
{		
	http_response_code(404);	
	$messageArr["name"] =[];//因為沒有帳號，我們就預設讓它為空陣列
	$messageArr["content"] = [];
	$messageArr["price"] = [];
    foreach($messageArr as $key => $value){
        $new_messageArr[urlencode($key)] = urlencode($value);
    }
    $messageArr_url = json_encode($new_messageArr);
    $messageArr = urldecode($messageArr_url);
	echo $messageArr;

}

?>