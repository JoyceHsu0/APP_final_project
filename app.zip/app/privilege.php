<?php 

$priv = 2;

?>