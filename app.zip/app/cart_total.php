<?php

//------------讀取資料庫--------------//	

	$servername = "192.168.2.200";
	$username = "slionf26_app_2023";
	$password = "root123456";
	$dbname = "slionf26_app_2023";
	$conn = new mysqli($servername, $username, $password, $dbname);

	//------------------------------------//
	// 建立資料庫連線
	$conn = new mysqli($servername, $username, $password, $dbname);
	// 確認資料是否正常連線
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
 $amountarray=array();
$pricearray = array();
	
      $sql = "SELECT * FROM `cart` ";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
          $amountarray[] = $row["p_num"];
          $pricearray[] = $row["p_price"];
		}
	  } 

  	  $cnt = count($amountarray);
      $total = 0;
$cart_total=array();
      for ($j = 0; $j < $cnt; $j++) {
            $total += $amountarray[$j] * $pricearray[$j];
	  }
$cart_total["total"]=$total;

	
	$conn->close();
	//------------------------------------------------
	



	http_response_code(200);
  echo json_encode($cart_total, JSON_UNESCAPED_UNICODE);





?>