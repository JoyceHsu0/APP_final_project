<?php include("connection.php"); ?>
<?php

	

$account = (isset($_GET['account'])) ? $_GET['account'] : "appuser";
$sql = "SELECT * FROM checkout WHERE `account`= '".@$account."' ;";
$dataarray= array();

if($result = mysqli_query($link, $sql)){  
   while($row = mysqli_fetch_assoc($result)){  
      $dataarray[] = $row; 
    
   } //end of while  
   $cnt = count($dataarray);
  $checkout_num = array();
  $checkout_num["cnt"]=$cnt;


}else{  
echo "0 results";  
}  

mysqli_free_result($result); // 釋放佔用的記憶體
mysqli_close($link); // 關閉資料庫連結
	//------------------------------------------------
	



  http_response_code(200);
  echo json_encode($checkout_num, JSON_UNESCAPED_UNICODE);





?>