<?php include("connection.php"); ?>
<?php
header('Content-Type: application/json; charset=UTF-8'); //設定資料類型為 json，編碼 utf-8
$sql = "SELECT * FROM cart";
$dataarray= array();

if($result = mysqli_query($link, $sql)){  
   while($row = mysqli_fetch_assoc($result)){  
      $dataarray[] = $row; 
      
   } //end of while  
  


}else{  
	echo "0 results";  
}  

mysqli_free_result($result); // 釋放佔用的記憶體
mysqli_close($link); // 關閉資料庫連結

http_response_code(200);
echo json_encode($dataarray, JSON_UNESCAPED_UNICODE);
	
?>