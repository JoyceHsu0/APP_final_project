<?php

//------------讀取資料庫--------------//	

	$servername = "192.168.2.200";
	$username = "slionf26_app_2023";
	$password = "root123456";
	$dbname = "slionf26_app_2023";
	$conn = new mysqli($servername, $username, $password, $dbname);

	//------------------------------------//
	// 建立資料庫連線
	$conn = new mysqli($servername, $username, $password, $dbname);
	// 確認資料是否正常連線
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	
      $sql = "DELETE FROM `cart` ;";
      $result = $conn->query($sql);
	
	$conn->close();
	//------------------------------------------------
	


if(!empty($_POST['p_id']))
{
	http_response_code(200);
  
}
else
{		
	http_response_code(404);	
}




?>

